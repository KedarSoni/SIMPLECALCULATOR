package com.example.calculater3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

double in1 =0,i2 = 0;
EditText editText1;
    boolean Add, Sub, Multiply, Divide, per, deci;
    TextView button_0, button_1, button_2, button_3, button_4, button_5, button_6, button_7, button_8, button_9, button_plus, button_minus,
            button_Mul, button_Div, button_Equ, button_Dot, button_per,button_ac;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button_0 = (TextView) findViewById(R.id.zero);
        button_1 = (TextView) findViewById(R.id.one);
        button_2 = (TextView) findViewById(R.id.two);
        button_3 = (TextView) findViewById(R.id.three);
        button_4 = (TextView) findViewById(R.id.four);
        button_5 = (TextView) findViewById(R.id.five);
        button_6 = (TextView) findViewById(R.id.six);
        button_7 = (TextView) findViewById(R.id.seven);
        button_8 = (TextView) findViewById(R.id.eight);
        button_9 = (TextView) findViewById(R.id.nine);
        button_Dot = (TextView) findViewById(R.id.dot);
        button_per= (TextView) findViewById(R.id.per);

        button_ac = (TextView) findViewById(R.id.ac);
        button_Equ = (TextView) findViewById(R.id.eq);


        button_plus = (TextView) findViewById(R.id.plus);
        button_minus= (TextView) findViewById(R.id.minus);
        button_Mul = (TextView) findViewById(R.id.multi);
        button_Div = (TextView) findViewById(R.id.div);


        editText1 = (EditText) findViewById(R.id.input);
        editText1.setShowSoftInputOnFocus(false);

        button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "1");
            }
        });
        button_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "2");
            }
        });
        button_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "3");
            }
        });
        button_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "4");
            }
        });
        button_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "5");
            }
        });
        button_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "6");
            }
        });
        button_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "7");
            }
        });
        button_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "8");
            }
        });
        button_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "9");
            }
        });
        button_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "0");
            }
        });
        button_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText1.getText().length() != 0) {
                    in1 = Float.parseFloat(editText1.getText() + "");
                    Add = true;
                    deci = false;
                    editText1.setText(null);
                }
            }
        });
        button_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText1.getText().length() != 0) {
                    in1 = Float.parseFloat(editText1.getText() + "");
                    Sub = true;
                    deci = false;
                    editText1.setText(null);
                }
            }
        });
        button_Mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText1.getText().length() != 0) {
                    in1 = Float.parseFloat(editText1.getText() + "");
                    Multiply = true;
                    deci = false;
                    editText1.setText(null);
                }
            }
        });
        button_Div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText1.getText().length() != 0) {
                    in1 = Float.parseFloat(editText1.getText() + "");
                    Divide = true;
                    deci = false;
                    editText1.setText(null);
                }
            }
        });
        button_per.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText1.getText().length() != 0) {
                    in1 = Float.parseFloat(editText1.getText() + "");
                    per = true;
                    deci = false;
                    editText1.setText(null);
                }
            }
        });
        button_Equ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Add || Sub || Multiply || Divide || per) {
                    i2 = Float.parseFloat(editText1.getText() + "");
                }

                if (Add) {

                    editText1.setText(in1 + i2 + "");
                    Add = false;
                }

                if (Sub) {

                    editText1.setText(in1 - i2 + "");
                    Sub = false;
                }

                if (Multiply) {
                    editText1.setText(in1 * i2 + "");
                    Multiply = false;
                }

                if (Divide) {
                    editText1.setText(in1 / i2 + "");
                    Divide = false;
                }
                if (per) {
                    editText1.setText(in1 % i2 + "");
                    per = false;
                }
            }
        });
        button_ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText("");
                in1 = 0.0;
                i2 = 0.0;
            }
        });

        button_Dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (deci) {
                    //do nothing or you can show the error
                } else {
                    editText1.setText(editText1.getText() + ".");
                    deci = true;
                }

            }
        });






    }
}
