package com.example.myapplication23;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


EditText id, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        id = findViewById(R.id.id);
        pass = findViewById(R.id.pass);



    }

    public void insta(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://www.instagram.com/accounts/login/"));
        startActivity(intent);
    }

    public void fb(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://www.facebook.com/"));
        startActivity(intent);
    }

    public void google(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("http://www.google.com"));
        startActivity(intent);
    }

    public void onnext(View view) {

        if (id.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter id", Toast.LENGTH_SHORT).show();
        } else if (pass.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter password", Toast.LENGTH_SHORT).show();
        } else {
            if (id.getText().toString().equals("123") && pass.getText().toString().equals("123")) {
                Intent i = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(i);
                Log.e("id is 123", id.getText().toString());
                Log.e("password is 123", pass.getText().toString());



            } else {
                Toast.makeText(this, "Access Denied", Toast.LENGTH_SHORT).show();
            }
        }


    }
}