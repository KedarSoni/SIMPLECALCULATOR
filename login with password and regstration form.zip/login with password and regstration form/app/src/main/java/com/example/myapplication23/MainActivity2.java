package com.example.myapplication23;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;

import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {



    EditText etName, etEmail, etPhone,birth_date, etAddress;
    RadioGroup rgGender;
    RadioButton rbtnMale, rbtnFemale,rbtnothers;
    CheckBox l1, l2, l3, l4, l5;
    LinearLayout llSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        birth_date = findViewById(R.id.birth_date);
        etAddress = findViewById(R.id.etAddress);
        rgGender = findViewById(R.id.rgGender);
        rbtnMale = findViewById(R.id.rbtnMale);
        rbtnFemale = findViewById(R.id.rbtnFemale);
        rbtnothers = findViewById(R.id.rbtnothers);
        l1 = findViewById(R.id._net);
        l2 = findViewById(R.id.java);
        l3 = findViewById(R.id.python);
        l4 = findViewById(R.id.php);
        l5 = findViewById(R.id.c_language);
        llSubmit = findViewById(R.id.ok);

        llSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etName.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Please enter name", Toast.LENGTH_SHORT).show();
                } else if (etEmail.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Please enter email", Toast.LENGTH_SHORT).show();
                }
                else if (!Patterns.EMAIL_ADDRESS.matcher(etEmail.getText().toString()).matches()) {
                    Toast.makeText(MainActivity2.this, "Please enter valid email address", Toast.LENGTH_SHORT).show();
                }else if (birth_date.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Please enter birth_date", Toast.LENGTH_SHORT).show();
                }

               else if (etPhone.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity2.this, "Please enter phone", Toast.LENGTH_SHORT).show();
                } else if (etAddress.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Please enter address", Toast.LENGTH_SHORT).show();
                } else if (!l1.isChecked() && !l3.isChecked() && !l3.isChecked() && !l4.isChecked() && !l5.isChecked()) {
                    Toast.makeText(MainActivity2.this, "Please select at least one language", Toast.LENGTH_SHORT).show();
                }
               else {
                    Log.e("name", etName.getText().toString());
                    Log.e("email", etEmail.getText().toString());
                    Log.e("phone", etPhone.getText().toString());
                    Log.e("address", etAddress.getText().toString());

                    Log.e("gender", rbtnMale.isChecked() ? "Male" : rbtnFemale.isChecked() ? "Female" : "Nothing");

                    if (l1.isChecked()) {
                        Log.e(".net", "selected");
                    }
                    if (l2.isChecked()) {
                        Log.e("java", "selected");
                    }
                    if (l3.isChecked()) {
                        Log.e("Python", "selected");
                    }
                    if (l4.isChecked()) {
                        Log.e("Php", "selected");
                    }
                    if (l5.isChecked()) {
                        Log.e("C language", "selected");
                    } if (llSubmit.isClickable()) {
                        Log.e("data", "send successfully");
                    } if (llSubmit.isClickable())  {
                        Toast.makeText(MainActivity2.this, "send successfully", Toast.LENGTH_SHORT).show();
                        etName.setText("");
                        etEmail.setText("");
                        etPhone.setText("");
                        birth_date.setText("");
                        etAddress.setText("");
                        rbtnMale.setChecked(true);
                        rbtnFemale.setChecked(false);
                        rbtnothers.setChecked(false);
                        l1.setChecked(false);
                        l2.setChecked(false);
                        l3.setChecked(false);
                        l4.setChecked(false);
                        l5.setChecked(false);


                        rbtnMale.setChecked(true);
                        rbtnFemale.setChecked(false);


                        l1.setChecked(false);


                    }

                }
            }
        });

    }




}
















/*
package com.example.myapplication23;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    EditText etName, etEmail, etPhone, etAddress,birth_date;

    RadioButton rbtnMale, rbtnFemale,rbtnothers;
    CheckBox _net, java, python, php, c_language;
    TextView ok;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        birth_date = findViewById(R.id.birth_date);
        etAddress = findViewById(R.id.etAddress);
        rbtnMale = findViewById(R.id.rbtnMale);
        rbtnFemale = findViewById(R.id.rbtnFemale);
        rbtnothers = findViewById(R.id.rbtnothers);
        _net = findViewById(R.id._net);
        java = findViewById(R.id.java);
        python = findViewById(R.id.python);
        php = findViewById(R.id.php);
        c_language = findViewById(R.id.c_language);
        ok = findViewById(R.id.ok);





        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void ok(View view) {
        if (etName.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity2.this, "Please enter name", Toast.LENGTH_SHORT).show();
        } else if (etEmail.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity2.this, "Please enter email", Toast.LENGTH_SHORT).show();
        } //else if (!Patterns.EMAIL_ADDRESS.matcher(etEmail.getText().toString()).matches()) {
        //Toast.makeText(MainActivity.this, "Please enter valid email address", Toast.LENGTH_SHORT).show();
        else if (etPhone.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity2.this, "Please enter phone", Toast.LENGTH_SHORT).show();
        }  else if (birth_date.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity2.this, "Please enter birth date", Toast.LENGTH_SHORT).show();
        }


        else if (etAddress.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity2.this, "Please enter address", Toast.LENGTH_SHORT).show();
        } else if (!_net.isChecked() && !java.isChecked() && !python.isChecked() && !php.isChecked() && !c_language.isChecked()) {
            Toast.makeText(MainActivity2.this, "Please select at least one programming language", Toast.LENGTH_SHORT).show();
        } else {
            Log.e("name", etName.getText().toString());
            Log.e("email", etEmail.getText().toString());
            Log.e("phone", etPhone.getText().toString());
            Log.e("birth_date", birth_date.getText().toString());
            Log.e("address", etAddress.getText().toString());

            Log.e("gender", rbtnMale.isChecked() ? "Male" : rbtnFemale.isChecked() ? "Female" : "Nothing");

            if (_net.isChecked()) {
                Log.e("_net ", "_net");
            }
            if (java.isChecked()) {
                Log.e("java ", "java");
            }
            if (python.isChecked()) {
                Log.e("python ", "python");
            }
            if (php.isChecked()) {
                Log.e("php ", "php");
            }
            if (c_language.isChecked()) {
                Log.e("c_language ", "c_language");
            }
            Intent i = new Intent(MainActivity2.this, MainActivity3.class);
            startActivity(i);

        }



    }
}


*/
